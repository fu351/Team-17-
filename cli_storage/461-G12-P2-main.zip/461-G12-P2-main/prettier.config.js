module.exports = {
    "printWidth": 240,
    "tabWidth": 4,
    "useTabs": false,
    "singleQuote": true,
    "trailingComma": "all",
    "semi": true
}