import { FC } from 'react';

import { ChatMessage } from '@/types/chatMessage';

export type RenderMessageExtra = FC<ChatMessage>;
