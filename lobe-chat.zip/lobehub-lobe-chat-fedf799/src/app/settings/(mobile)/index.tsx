import Index from './mobile';

export default () => <Index />;
