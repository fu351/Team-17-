import Page from './home';
import Redirect from './home/Redirect';

const Index = () => (
  <>
    <Page />
    <Redirect />
  </>
);

export default Index;
