export const PLUGIN_SCHEMA_SEPARATOR = '____';
