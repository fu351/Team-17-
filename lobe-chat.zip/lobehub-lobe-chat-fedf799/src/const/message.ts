export const LOADING_FLAT = '...';

// 只要 start with 这个，就可以判断为 function message
export const FUNCTION_MESSAGE_FLAG = '{"function';

export const FUNCTION_LOADING = 'FUNCTION_LOADING';
