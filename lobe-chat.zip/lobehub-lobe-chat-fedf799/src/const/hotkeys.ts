export const PREFIX_KEY = 'alt';
export const META_KEY = 'mod';
export const SAVE_TOPIC_KEY = 'n';
export const CLEAN_MESSAGE_KEY = 'backspace';
export const REGENERATE_KEY = 'r';
