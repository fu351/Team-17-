# 数据统计

为更好地帮助分析 LobeChat 的用户使用情况，我们在 LobeChat 中集成了若干免费 / 开源的数据统计服务，用于收集用户的使用情况，你可以按需开启。

## Vercel Analytics

[Vercel Analytics](https://vercel.com/analytics) 是 Vercel 推出的一款数据分析服务，它可以帮助你收集网站的访问情况，包括访问量、访问来源、访问设备等等。

我们在代码中集成了 Vercel Analytics，你可以通过设置环境变量 `NEXT_PUBLIC_ANALYTICS_VERCEL=1` 来开启它，并打开 Vercel 部署项目中 Analytics tab 查看你的应用访问情况。

Vercel Analytics 提供了 2500 次 / 月的免费 Web Analytics Events (可以理解为 PV)，对于个人部署自用的产品来说基本够用。

如果你需要了解 Vercel Analytics 的详细使用教程，请查阅[Vercel Web Analytics 快速开始](https://vercel.com/docs/analytics/quickstart)

## 🚧 Posthog
