# Ece461Fall2023ProjectPhase2.PackageMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**PackageName**](PackageName.md) |  | 
**version** | **String** | Package version | 
**ID** | [**PackageID**](PackageID.md) |  | 
