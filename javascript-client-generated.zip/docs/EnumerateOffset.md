# Ece461Fall2023ProjectPhase2.EnumerateOffset

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
