# Ece461Fall2023ProjectPhase2.PackageQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | [**SemverRange**](SemverRange.md) |  | [optional] 
**name** | [**PackageName**](PackageName.md) |  | 
