# Ece461Fall2023ProjectPhase2.SemverRange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
