# Ece461Fall2023ProjectPhase2.User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**isAdmin** | **Boolean** | Is this user an admin? | 
