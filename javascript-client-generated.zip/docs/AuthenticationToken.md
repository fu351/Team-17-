# Ece461Fall2023ProjectPhase2.AuthenticationToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
