# Ece461Fall2023ProjectPhase2.ModelPackage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metadata** | [**PackageMetadata**](PackageMetadata.md) |  | 
**data** | [**PackageData**](PackageData.md) |  | 
