# Ece461Fall2023ProjectPhase2.UserAuthenticationInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**password** | **String** | Password for a user. Per the spec, this should be a \&quot;strong\&quot; password. | 
