# Ece461Fall2023ProjectPhase2.AuthenticationRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user** | [**User**](User.md) |  | 
**secret** | [**UserAuthenticationInfo**](UserAuthenticationInfo.md) |  | 
